using System.Windows.Forms;

namespace TelegramConnected
{
  class Program
  {
    public static void Main(string[] args)
    {
      Application.Run(new Form1());
    }
  }
}
