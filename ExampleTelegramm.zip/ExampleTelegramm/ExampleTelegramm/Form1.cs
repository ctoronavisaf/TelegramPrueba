using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeleSharp.TL;
using TLSharp.Core;

namespace TelegramConnected
{
  public partial class Form1 : Form
  {
    
    public Form1()
    {
      InitializeComponent();
    }
    private void Form1_Load(object sender, EventArgs e)
    {

    }

    async void Button1_Click(object sender, EventArgs e)
    {
              //get available contacts
        var client = new TelegramClient(219685, "35011aa62636c78f4a52326cc2287e78");
        await client.ConnectAsync();
         Thread.Sleep(1000);

      var hash = await client.SendCodeRequestAsync("+573128900512");
      var code = "11070"; // you can change code in debugger //code will send via telegram to you
      Thread.Sleep(2000);

      TLUser user = null;
        try
        {
        user = await client.MakeAuthAsync("+573128900512", hash, code);
        Thread.Sleep(2000);
      }
        catch (CloudPasswordNeededException ex)
        {
          //if u activate two step verification in telegram
          var password = await client.GetPasswordSetting();
          var password_str = "2345";

          user = await client.MakeAuthWithPasswordAsync(password, password_str);
        }

        if (client.IsUserAuthorized())
        {
          //get available contacts
          var result = await client.GetContactsAsync();
        Thread.Sleep(2000);

        //find recipient in contacts
        var userr = result.Users
              .Where(x => x.GetType() == typeof(TLUser))
              .Cast<TLUser>()
              .FirstOrDefault(x => x.Phone == "573006957748"); //573105340696 David
        Thread.Sleep(2000);
        //send message
        await client.SendMessageAsync(new TLInputPeerUser() { UserId = userr.Id }, "My Message  :Hi :)");
        Thread.Sleep(2000);
      }
      }

    }
  }

